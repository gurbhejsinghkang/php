<?php

function array_to_html_table($product)
{
    $r = '';
    $r .= '<style> td,th{border:1px solid black;}</style>';
    $r .= '<table>';
    $r .= '<tr>';
    $r .= '<th>index</th><th>Value</th>';
    $r .= '</tr>';

    foreach ($product as $key => $value) {
        $r .= '<tr>';
        $r .= '<td>'.$key.'</td>';
        $r .= '<td>'.$value.'</td>';
        $r .= '</tr>';
    }
    $r .= '</table>';

    return $r;
}
function array_to_html_table2($product)
{
    $r = '';
    $r .= '<style> td,th{border:1px solid black;}</style>';
    $r .= '<table>';
    $r .= '<tr>';
    $r .= '<th>id</th><th>Name</th>
    <th>Description</th><th>Price</th>
    <th>Pic</th><th>Stock</th>';
    $r .= '</tr>';

    foreach ($product as $value) {
        $r .= '<tr>';
        foreach ($value as $values) {
            $r .= '<td>'.$values.'</td>';
        }
        $r .= '</tr>';
    }
    $r .= '</table>';

    return $r;
}
function array_to_html_table3($product)
{
    $r = '';
    foreach ($product as $value) {
        $r .= array_to_html_table4($value);
    }

    return $r;
}
function Crash($code, $message)
{
    http_response_code($code);
    mail(COMPANY_EMAIL, COMPANY_NAME, 'Server Crashed Code='.$code, $message); //here email to IT Admin
    $file = fopen('Logs/errors.log', 'a+');
    $time_info = date('d-m-y h i s a');
    fwrite($file, $message.'-'.$time_info.' <br>');
    $message = fread($myfile, filesize('Logs/errors.log'));
    fclose($file);
    die($message);
}

function array_to_html_table4($product)
{
    $r = "<div class='product'>";
    $r .= '<img src=productimages/'.$product['pic'].'>';
    $r .= '<h1 class="name">'.$product['name'].'</h1>';
    $r .= '<h1 class="description">'.$product['description'].'</h1>';
    $r .= '<h1 class="price">'.$product['price'].'</h1>';
    $r .= '</div>';

    return $r;
}
// function product_Catalogue($product)
// {
//     $r = '';
//     $r .= '<style> td,th{border:1px solid black;}</style>';

//     return $r;
//     $out = '';
//     if (count($table) == 0) {
//         //table is empty
//     }
//     $out .= '<table>';
//     $col_names = array_keys($table[0]);
//     $out .= '<tr>';
//     //table header
//     $col_names = array_keys($product);
//     foreach ($table as $one_row) {
//     }

//     //table data
//     // foreach ($products as $one_product) {
//     //     if($one_product['qty_in_stock'])
//     //     {
//     //         $page['$one_product']=
//     //     }
//     // }
//}
