<?php

define('COMPANY_PHONE', '514-123-4567');
define('COMPANY_EMAIL', 'servise@electricscooter.com');
define('WEB_SITE_NAME', 'Electricscooter.com');
define('PAGE_DEFAULT_TITLE', 'Welcome to ElectricScooters.com');
define('PAGE_DEFAULT_DESCRIPTION', 'Welcome to ElectricScooters.com');
define('PAGE_DEFAULT_AUTHOR', 'Welcome to ElectricScooters.com');
define('PAGE_DEFAULT_ICON', 'Welcome to ElectricScooters.com');
define('PAGE_DEFAULT_LANG', 'Welcome to ElectricScooters.com');
