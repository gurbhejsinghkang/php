<?php
 
$product = [
'id' => 0,
'name' => 'BlackDress',
'descrition' => 'Little black evening dress',
'price' => 99.99,
];
 
arrray_to_html_table($array_name)
{
$r = '';
$r = '<style> td,th{border:1px solid black;}</style>';
$r = '<table>';
$r = '<tr>';
$r = '<th>index</th><th>Value</th>';
$r = '</tr>';
 
foreach ($array_name as $key => $value) {
$r = '<tr>';
$r = '<td>'.$key.'</td>';
$r = '<td>'.$value.'</td>';
$r = '</tr>';
    }
$r = '</table>';
 
return$r;
}
//array_display($product);
//$winning_numbers = [33, 46, 23, 1, 67];
//array_display($winning_numbers);
//die();

